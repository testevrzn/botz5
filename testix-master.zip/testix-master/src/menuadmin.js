const menuadmin = (prefix, pushname) => {
 return `Olá esse é o menu dos admin
 _obs o bot precisa ser admin para exutar esses comandos_
 
 ❍ *COMANDO DOS ADMINS*
 │
 ║➩ ❍ ${prefix}abrirgp
 ║➩ ❍ ${prefix}fechargp
 ║➩ ❍ ${prefix}promover
 ║➩ ❍ ${prefix}rebaixar
 ║➩ ❍ ${prefix}marcar
 ║➩ ❍ ${prefix}marcar2
 ║➩ ❍ ${prefix}marcar3
 ║➩ ❍ ${prefix}marcar4
 ║➩ ❍ ${prefix}marcarl5
 ║➩ ❍ ${prefix}add
 ║➩ ❍ ${prefix}remover
 ║➩ ❍ ${prefix}listadmins
 ║➩ ❍ ${prefix}linkgp
 ║➩ ❍ ${prefix}sairgp
 ║➩ ❍ ${prefix}bv
 ║➩ ❍ ${prefix}nsfw
 ║➩ ❍ ${prefix}leveling
 ║➩ ❍ ${prefix}level
 ║➩ ❍ ${prefix}apagar
 ║➩ ❍ ${prefix}simih
 ║➩ ❍ ${prefix}donogp
 `


}

exports.menuadmin = menuadmin