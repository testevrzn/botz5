const help = (prefix) => {
	return `🔰--[ *BOT SADSTATION* ]--🔰
 
 ✧͢⃟ᤢ🌸ŠΔ̸Đ᭨ŠŤΔ̸ŤIΩN⋆⃟ۣۜ🎡
░░░░░▀▄░▄▀░░░░░​
​░​​​░░◢███████◣░░░​
​░​​​​​░◢██▀███▀██◣░░​
​​​░░​███████████░░​ 
░░​▅▅▅▅▅▅▅▅▅▅▅░░​
◢█​█▀███████▀██◣ 
​███▀███████▀███
███▀███████▀███ ​
███▀███████▀███ 
███▀███████▀███ ​
◥◤█▀███████▀█◥◤
​░​░██▀█████▀██░░​
​░░​◥█████████◤░​░​
​░░░◥███████◤░░░​
​░​░░░​███░███░​░░░​
​​░░░░​███░​███░░░​░​
​░░​░░◥█◤░◥█◤░░​░​░
   ✧͢⃟ᤢ🌸ŠΔ̸Đ᭨ŠŤΔ̸ŤIΩN⋆⃟ۣۜ🎡
    
◆ ▬▬▬▬▬ ❴✪❵ ▬▬▬▬▬ ◆
࿗᭄ PROPRIETÁRIO : *TIO WILL*
࿗᭄ INSTAGRAM: @putswill
࿗᭄ ATIVO : *08:00-22:00 WIB*
࿗᭄ PREFIX : 「 ${prefix} 」
࿗᭄ VERSÃO : 1.1
࿗᭄ CRIADOR: wa.me/+5516991541171
࿗᭄ CANAL: https://youtube.com/c/willtipografias
࿗᭄ MEU GRUPO: https://chat.whatsapp.com/IXX8rnNjDzFCuuDcpMdloQ
࿗᭄ SE FOR COPIAR DEIXA OS DIREITOS AUTORAIS DO TIO WILL
◆ ▬▬▬▬▬ ❴✪❵ ▬▬▬▬▬ ◆

                 ❍ 𝚂𝙾𝙱𝚁𝙴
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}info
  ║➩ ❍ ${prefix}blocklist
  ║➩ ❍ ${prefix}chatlist
  ║➩ ❍ ${prefix}ping
  ║➩ ❍ ${prefix}bugreport
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
                ❍ 𝙵𝙰𝚉𝙴𝚁
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}figu
  ║➩ ❍ ${prefix}toimg
  ║➩ ❍ ${prefix}virarmp3
  ║➩ ❍ ${prefix}bpink
  ║➩ ❍ ${prefix}marvellogo
  ║➩ ❍ ${prefix}snowwrite
  ║➩ ❍ ${prefix}3dtext
  ║➩ ❍ ${prefix}ninjalogo
  ║➩ ❍ ${prefix}water
  ║➩ ❍ ${prefix}firetext
  ║➩ ❍ ${prefix}logowolf
  ║➩ ❍ ${prefix}logowolf2
  ║➩ ❍ ${prefix}phlogo
  ║➩ ❍ ${prefix}glitch
  ║➩ ❍ ${prefix}neonlogo
  ║➩ ❍ ${prefix}neonlogo2
  ║➩ ❍ ${prefix}lionlogo
  ║➩ ❍ ${prefix}jokerlogo
  ║➩ ❍ ${prefix}shadow
  ║➩ ❍ ${prefix}burnpaper
  ║➩ ❍ ${prefix}coffee
  ║➩ ❍ ${prefix}lovepaper
  ║➩ ❍ ${prefix}woodblock
  ║➩ ❍ ${prefix}qowheart
  ║➩ ❍ ${prefix}mutgrass
  ║➩ ❍ ${prefix}undergocean
  ║➩ ❍ ${prefix}woodenboards
  ║➩ ❍ ${prefix}wolfmetal
  ║➩ ❍ ${prefix}metalictglow
  ║➩ ❍ ${prefix}8bit
  ║➩ ❍ ${prefix}ttp
  ║➩ ❍ ${prefix}herrypotter
  ║➩ ❍ ${prefix}pubglogo
  ║➩ ❍ ${prefix}quotemaker
  ║➩ ❍ ${prefix}textoft
  ║➩ ❍ ${prefix}calunia
  ║➩ ❍ ${prefix}shota
  ║➩ ❍ ${prefix}dere
 ✦┅┅┅┅ೋೋ┅┅┅┅✦
                 ❍ 𝙼𝙴𝙳𝙸𝙰
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}trendtwit
  ║➩ ❍ ${prefix}randomkpop
  ║➩ ❍ ${prefix}ytsearch
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
          ❍ 𝙵𝙰𝙻𝙰𝙻𝙰𝚁 𝙲𝙾𝙼 𝙱𝙾𝚃
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}chatwill
  ║➩ ❍ ${prefix}whatday
  ║➩ ❍ ${prefix}avalie
  ║➩ ❍ ${prefix}chatpode
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
                ❍ 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}images
  ║➩ ❍ ${prefix}ytmp3
  ║➩ ❍ ${prefix}ytmp4
  ║➩ ❍ ${prefix}tiktok
  ║➩ ❍ ${prefix}joox
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
                  ❍ 𝙼𝙴𝙼𝙴
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}meme
  ║➩ ❍ ${prefix}memeindo
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
                   ❍ 𝚂𝙾𝙼
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}musica
  ║➩ ❍ ${prefix}audio
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
                ❍ 𝙼𝚄𝚂𝙸𝙲𝙰
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}lirik
  ║➩ ❍ ${prefix}chord
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
               ❍ 𝚂𝚃𝙰𝙻𝙺𝙴𝙰𝚁
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}tiktokstalk
  ║➩ ❍ ${prefix}igstalk
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
                ❍ 𝙰𝙽𝙸𝙼𝙴𝚂
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}neonime
  ║➩ ❍ ${prefix}pokemon
  ║➩ ❍ ${prefix}loli
  ║➩ ❍ ${prefix}waifu
  ║➩ ❍ ${prefix}randomanime
  ║➩ ❍ ${prefix}husbu
  ║➩ ❍ ${prefix}husbu2
  ║➩ ❍ ${prefix}buscanime
  ║➩ ❍ ${prefix}nekonime
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
       ❍ 𝙴𝙽𝚃𝚁𝙴𝚃𝙴𝚁𝙸𝙼𝙴𝙽𝚃𝙾𝚂
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}alay
  ║➩ ❍ ${prefix}gantengcek
  ║➩ ❍ ${prefix}watak
  ║➩ ❍ ${prefix}hobby
  ║➩ ❍ ${prefix}game
  ║➩ ❍ ${prefix}bucin
  ║➩ ❍ ${prefix}trust
  ║➩ ❍ ${prefix}dare
  ║➩ ❍ ${prefix}simi
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
       ❍ 𝙲𝙾𝙼𝙰𝙽𝙳𝙾𝚂 𝙳𝙴 𝙰𝚄𝙳𝙸𝙾
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}bahasa
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
               ❍ 𝙳𝙾𝙽𝙾
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}setprefix
  ║➩ ❍ ${prefix}block
  ║➩ ❍ ${prefix}bc
  ║➩ ❍ ${prefix}bcgc
  ║➩ ❍ ${prefix}clone
  ║➩ ❍ ${prefix}clearall
  ✦┅┅┅┅ೋೋ┅┅┅┅✦
                 ❍ 𝙾𝚄𝚃𝚁𝙾𝚂
 ✦┅┅┅┅ೋೋ┅┅┅┅✦
  ║➩ ❍ ${prefix}send
  ║➩ ❍ ${prefix}wame
  ║➩ ❍ ${prefix}virtex
  ║➩ ❍ ${prefix}exe
  ║➩ ❍ ${prefix}qrcode
  ║➩ ❍ ${prefix}afk
  ║➩ ❍ ${prefix}timer
  ║➩ ❍ ${prefix}fml
  ║➩ ❍ ${prefix}fml2
  ✦┅┅┅┅ೋೋ┅┅┅┅✦

✎﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏
 ⟪ CRIADO POR  *TIO WILL* ⟫
                           *@PUTSWILL* 
✎﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏


`
}

exports.help = help
