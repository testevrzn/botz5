const willmenu = (prefix, pushname) => {
    return `❍ *Comandos do Will*
    
    ║➩ ❍ ${prefix}setprefix
    ║➩ ❍ ${prefix}block
    ║➩ ❍ ${prefix}tm
    ║➩ ❍ ${prefix}tmctt
    ║➩ ❍ ${prefix}clearall`

}

exports.willmenu = willmenu