const config = {
        botName: 'Willbot',
        ownerName: 'Will',
}
